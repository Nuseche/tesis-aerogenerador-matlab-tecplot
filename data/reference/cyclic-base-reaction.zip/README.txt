Cyclic-geometry control for the 3P tower-base moment
====================================================

Run from the structural-model repository root in MATLAB:

    addpath('tools')
    check_cyclic_base_reaction

The script rebuilds both rotors from versioned inputs in SI units. It preserves the
133-element mesh topology, tower, transition, drivetrain, hub, nacelle, support,
section properties and Rayleigh damping (0.5% at 0.17 and 1 Hz). For the cyclic
control, blade-1 nodes and auxiliary points are copied through exact shaft
rotations of 120 and 240 degrees. Reference frames, blade-root constraints,
inertias and centrifugal tension are recomputed. Gravity and aerodynamic loads
are absent. The forcing is a unit axial hub force at three cycles per turn.

response.csv records the complex 3P base moment about global Y as amplitude
(N m/N) and phase (degrees relative to the cosine force) and the relative L2
difference (%) over one revolution using the same periodic reference. The 57
speeds include 3.4445 rpm and a 0.002-rpm grid from 3.364 through 3.474. All
speeds use H=6, with two H=12 spot checks per rotor at 3.394 and 3.4445 rpm.

geometry.csv reports maximum deviations of each inherited/cyclic blade from
the rotated blade-1 nodes and auxiliaries, as well as nodal frame Frobenius
differences and local element mass/stiffness relative Frobenius differences.
The final column tests off-grid Fourier reconstruction of the assembled
operators.

stiffness_harmonics.csv gives the unfiltered relative Frobenius norm of each
Fourier coefficient of the zero-speed transformed elastic stiffness (i.e. at
each fixed azimuth). The denominator is the norm of its zeroth coefficient on
that rotor. The calculation samples 64 equally spaced azimuths using the same
coordinate scaling (nodal translations in metres and rotations in radians) for
both models. The response solver discards Fourier coefficients below its
relative family threshold of 1e-12. Numerically identical moment histories on
the cyclic rotor should be interpreted at that numerical resolution.
