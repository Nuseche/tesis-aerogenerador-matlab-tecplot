# Ejecución y reanudación de Morris

Caso aprobado: `cases/config_sensitivity_morris_approved.m`. La configuración separa el dominio exploratorio de las propiedades físicas originales. `cases/config_sensitivity_extended_pending.m` permanece como ficha histórica no ejecutable de la propuesta; no es la entrada de esta etapa.

```matlab
addpath('/Users/nuseche/Desktop/Tesis_codigos');
addpath('/Users/nuseche/Desktop/Tesis_codigos/cases');
folder='/Users/nuseche/Desktop/Tesis_codigos/runs/sensitivity/morris_20261006';
campaign=sensitivity.run_morris_study(folder,"2026-10-07 01:48:29");
```

La marca UTC representa el inicio de la preparación de la campaña del 6 de octubre, a las 20:48:29 de Bogotá. Es parte de la configuración guardada y del presupuesto. Repetir esta llamada con la misma versión reutiliza los MAT existentes, incluidos fallos; no vuelve a resolverlos. El cambio de configuración, código, datos o versión MATLAB impide reanudar la misma carpeta. No cambie el inicio para extender el presupuesto de la campaña original. Para una futura campaña con presupuesto autorizado, use una carpeta nueva y el inicio correspondiente.

`campaign.mat/json` contiene la semilla y todos los casos, de modo que el diseño es recuperable incluso si la ejecución se interrumpe antes de guardar `morris_design.mat`. El diseño también está en `morris_vertices.csv` y `morris_edges.csv`. El ejecutor deja estados pendientes al agotarse el presupuesto; la comprobación se hace antes de iniciar cada evaluación.

Los checkpoints a 10, 20 y 40 trayectorias se generan durante la ejecución. Para reanalizar los casos almacenados, sin nuevos solves:

```matlab
saved=load(fullfile(folder,'campaign.mat'),'campaign');
summary=sensitivity.summarize_morris(saved.campaign);
run('/Users/nuseche/Desktop/Tesis_codigos/docs/sensibilidad_morris_20261006/export_results.m');
```

Luego `python3 build_delivery.py` genera la discusión a partir de `report_data.json` y conserva los archivos LaTeX que ya existen. Solo crea la plantilla inicial si faltan; la opción explícita `--replace-latex` reemplaza la versión ilustrada por esa plantilla inicial. Para reconstruir la versión ilustrada del documento abierto, use `python3 revision_reunion/expand_document.py`: lee resultados guardados y escribe en el mismo `SECCION_MORRIS_REVISION.tex`, sin nuevas evaluaciones del modelo. Sus ocho figuras vectoriales incluyen datos y gráficos directamente en la fuente y no requieren archivos externos.

La fuente anterior a esta ampliación se conserva en `revision_reunion/source_before_edit.txt`. `revision_reunion/revision_provenance.json` identifica los datos utilizados y la huella de la fuente ampliada. El LaTeX autónomo se compila con el editor nativo de Codex; no necesita TeX instalado en la terminal. Después de cualquier cambio de fuente, confirme esa compilación y actualice su huella en `latex_compilation.json` antes de ejecutar `audit_delivery.py`, que comprueba fuentes, resultados y compilación y escribe el manifiesto SHA-256.

Use `morris_summary.mat` para análisis MATLAB. Si se importan CSV, fuerce `group` a texto; etiquetas como `10+11` no deben interpretarse numéricamente. Los grupos son conjuntos de ramas de la referencia, no índices de frecuencia ordenada en cada punto. `allEffectsValid`, `meanEffectResolved`, `muStarConverged`, `dispersionResolved` y `sigmaConverged` deben conservarse al interpretar la tabla. Las aristas inválidas permanecen explícitas; no las elimine para recalcular una clasificación optimista.

Las figuras usan escalas adimensionales de respuesta y exportan PNG y PDF vectorial. `morris_dominio` muestra puntos calculados; su color mezcla el efecto de los tres factores y no debe interpretarse como un barrido de un solo parámetro.
