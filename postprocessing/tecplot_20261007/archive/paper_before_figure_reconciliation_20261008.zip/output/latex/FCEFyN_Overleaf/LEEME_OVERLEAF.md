# Importación en Overleaf

1. Crear un proyecto mediante New Project > Upload Project y seleccionar este ZIP completo.
2. Seleccionar FCEFyN_ES.tex (español) o FCEFyN_EN.tex (inglés) como Main document.
3. Seleccionar el compilador XeLaTeX y el modo de compilación Normal, no Fast [draft].
4. Ejecutar Recompile from scratch.

Las figuras están integradas como código TikZ y no dependen de una carpeta figures. La clase y la bibliografía siguen siendo archivos necesarios; el logotipo editorial permanece en filesFCEFyN-class/FCEFyN_logo.pdf. Por eso debe importarse la carpeta completa como proyecto, no únicamente copiar el texto del manuscrito.

Esta variante se compiló localmente con Tectonic (motor XeTeX); no se accedió al proyecto del usuario en Overleaf. Si continúa el problema, compartir el primer error del registro de compilación y una captura del árbol de archivos, sin credenciales.

El paquete anterior contenía las figuras y las rutas coincidían. Sin el registro de Overleaf no se atribuye el fallo a una causa confirmada. La compilación en modo borrador puede ocultar imágenes: https://docs.overleaf.com/troubleshooting-and-support/resolving-pdf-rendering-and-project-loading-problems/resolving-problems-with-missing-images

La plantilla editorial y los seis autores, con su orden original, se conservan intactos. El 1 de octubre de 2026 se revisó FCEFyN_ES.tex para precisar la cinemática, las bases de componentes, las propiedades seccionales y las ecuaciones, además de ampliar los esquemas y actualizar sus referencias. Los términos del giro se describen como contribuciones inerciales de la rotación prescrita, no como cargas externas. La versión completa FCEFyN_EN.tex y los PDF y ZIP de septiembre corresponden a la redacción anterior; no deben presentarse como traducción o exportación de esta revisión.
