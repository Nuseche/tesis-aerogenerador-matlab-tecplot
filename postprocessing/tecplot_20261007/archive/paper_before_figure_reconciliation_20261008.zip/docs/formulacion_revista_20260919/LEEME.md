# Formulación matemática para Revista FCEFyN

Este paquete contiene dos versiones completas del mismo manuscrito: español e inglés. El alcance es exclusivamente el modelo matemático y su formulación, con tres apéndices dentro de cada documento. No incluye resultados numéricos, campañas de comparación, métricas de desempeño ni capítulos de pruebas de software.

## Contenido

- `FCEFyN_ES.tex`: manuscrito español completo.
- `FCEFyN_EN.tex`: manuscrito inglés completo.
- `Referencias.bib`: las siete referencias citadas.
- `FCEFyN-class.cls` y `filesFCEFyN-class/`: clase, estilos bibliográficos y logotipo oficiales, sin modificaciones.
- `figures/`: esquema vectorial en ambos idiomas y sus fuentes TikZ.
- `SOURCE_TEMPLATE.md`: procedencia de la plantilla.
- Los dos PDF compilados.

Los archivos `.tex` distribuidos integran el cuerpo y los apéndices; no necesitan archivos `cuerpo_es.tex` ni `cuerpo_en.tex`. Los archivos de trabajo en `docs/formulacion_revista_20260919/` conservan esos componentes para facilitar la edición.

## Compilación

Ejecutar desde la carpeta que contiene los manuscritos y la clase:

```sh
tectonic FCEFyN_ES.tex
tectonic FCEFyN_EN.tex
```

Alternativamente, utilizar una distribución completa de LaTeX con `latexmk -pdf FCEFyN_ES.tex` o `latexmk -pdf FCEFyN_EN.tex`. La compilación verificada para esta entrega se realizó con Tectonic. En Overleaf, subir todos los archivos conservando las carpetas y seleccionar el manuscrito correspondiente como documento principal.

Los esquemas PDF ya están incluidos. Para regenerarlos, compilar `esquema_es.tex` y `esquema_en.tex` desde `figures/`.

## Decisiones editoriales

Se utilizaron las normas de https://revistas.unc.edu.ar/index.php/FCEFyN/about/submissions y la plantilla enlazada por la página institucional de instrucciones, consultadas el 19 de septiembre de 2026. Se conservaron la clase y sus medidas. El título, los resúmenes y las palabras clave están en los dos idiomas. Los resúmenes se adaptaron al nuevo alcance con autorización expresa del usuario.

Se conservaron los seis autores y el orden del manuscrito MECOM: Diego F. Turello, Mauro S. Maza, Nicolás Andrés Useche Castillo, Omar Lopez, Sergio Preidikman y Federico Pinto. Las filiaciones se expresaron institucionalmente; no se agregaron autores ni identificadores ORCID. El correo de Diego F. Turello procede del documento MECOM suministrado; se utilizó para correspondencia y debe ser confirmado por los autores antes del envío.

Las fechas editoriales, volumen y número permanecen sin asignar. No se inventaron aceptación, financiación ni declaraciones de aprobación de los coautores. La declaración de asistencia de IA se incluyó antes de las referencias conforme a las normas actuales de la revista; los autores deben revisar su redacción y confirmar su alcance antes del envío.

Por su contenido exclusivamente metodológico, el manuscrito es compatible conceptualmente con la categoría de nota técnica contemplada por la revista. No se ha enviado a la revista ni se afirma aceptación editorial. Deben confirmarse la categoría, las filiaciones vigentes, la correspondencia y cualquier requisito adicional de la plataforma antes de enviarlo.

## Alcance matemático

Se conserva la derivación energética vigente de la masa espacial, el acoplamiento velocidad--posición, la giroscopía y la tangente centrífuga. Se distinguen operadores seccionales y ensamblados, el transporte inercial, las restricciones raíz--cubo y la transformación multiblade. La formulación local usa el azimut de referencia, inercias de referencia y pequeñas rotaciones deformacionales. La interfaz de viento es general, no una simulación aerodinámica calibrada. La excitación puramente inercial de base se presenta junto con las condiciones que permiten omitir términos de desplazamiento y velocidad del apoyo.

Esta entrega documenta la formulación; no modifica el solver ni recalcula resultados del proyecto.
